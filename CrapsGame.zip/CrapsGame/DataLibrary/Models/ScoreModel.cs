﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Models
{
    public class ScoreModel
    {
        public int  PlayerId { get; set; }
        public int  Score { get; set; }
        public string Result { get; set; }
    }
}
