﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DataLibrary.DataAccess;
using DataLibrary.Models;

namespace DataLibrary.GameLogic
{
    public static class GameProcessor
    {
        public static int CreatePlayer( string name)
        {
            PlayerModel data = new PlayerModel {Name = name};

            string sql = @"insert into dbo.Players (Name) values (@Name); SELECT SCOPE_IDENTITY()";
            return SqlDataAccess.SaveDataScalar(sql, data);
        }

        public static List<PlayerModel> LoadPlayers()
        {
            string sql = @"select Id, Name from dbo.Players";

            return SqlDataAccess.LoadData<PlayerModel>(sql);
        }

        public static int EditPlayer(int id, string name)
        {
            PlayerModel data = new PlayerModel {Id = id, Name = name};

            string sql = @"update dbo.Players set Name = @Name where Id = @id;";

            return SqlDataAccess.SaveData(sql, data);
        }

        public static int DeletePlayer(int id)
        {
            PlayerModel data = new PlayerModel {Id = id};

            string sql = @"delete from dbo.Players where Id = @id;";
            return SqlDataAccess.SaveData(sql, data);
        }

        public static int SaveGame(int playerId, string result, int point)
        {
            ScoreModel data = new ScoreModel { PlayerId = playerId, Result = result, Score=point};

            string sql = @"insert into dbo.Score (PlayerId, Result, Score) values (@PlayerId, @Result, @Score);";

            return SqlDataAccess.SaveData(sql, data);
        }

        public static int ClearGame(int playerId)
        {
            ScoreModel data = new ScoreModel { PlayerId = playerId };

            string sql = @"delete from dbo.Score where PlayerId = @playerId;";
            return SqlDataAccess.SaveData(sql, data);
        }
        public static List<ScoreModel> LoadScores(int playerId)
        {
            ScoreModel data = new ScoreModel { PlayerId = playerId };
            string sql = @"select * from dbo.Score where PlayerId = @playerId;";

            return SqlDataAccess.LoadDataScore<ScoreModel>(sql, data);
        }
    }
}
