﻿namespace CrapsGame
{
    partial class CrapsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.newPlayer = new System.Windows.Forms.Button();
            this.loadPlayer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.playerPoints = new System.Windows.Forms.Label();
            this.rollDice = new System.Windows.Forms.Button();
            this.dice2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dice1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.quit = new System.Windows.Forms.Button();
            this.editPlayer = new System.Windows.Forms.Button();
            this.deletePlayer = new System.Windows.Forms.Button();
            this.clearHistory = new System.Windows.Forms.Button();
            this.playerName = new System.Windows.Forms.TextBox();
            this.saveUser = new System.Windows.Forms.Button();
            this.GameHistory = new System.Windows.Forms.DataGridView();
            this.PlayerDataView = new System.Windows.Forms.DataGridView();
            this.PlayerDataLabel = new System.Windows.Forms.Label();
            this.GamePanel = new System.Windows.Forms.Panel();
            this.Replay = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.GameHistory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerDataView)).BeginInit();
            this.GamePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Papyrus", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(281, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "DICE GAME: CRAPS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // newPlayer
            // 
            this.newPlayer.Location = new System.Drawing.Point(15, 63);
            this.newPlayer.Name = "newPlayer";
            this.newPlayer.Size = new System.Drawing.Size(104, 44);
            this.newPlayer.TabIndex = 2;
            this.newPlayer.Text = "New Player";
            this.newPlayer.UseVisualStyleBackColor = true;
            this.newPlayer.Click += new System.EventHandler(this.button1_Click);
            // 
            // loadPlayer
            // 
            this.loadPlayer.Location = new System.Drawing.Point(151, 63);
            this.loadPlayer.Name = "loadPlayer";
            this.loadPlayer.Size = new System.Drawing.Size(102, 44);
            this.loadPlayer.TabIndex = 3;
            this.loadPlayer.Text = "Load Player";
            this.loadPlayer.UseVisualStyleBackColor = true;
            this.loadPlayer.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(521, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Game History";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Player Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(263, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Points";
            // 
            // playerPoints
            // 
            this.playerPoints.AutoSize = true;
            this.playerPoints.BackColor = System.Drawing.SystemColors.ControlDark;
            this.playerPoints.Location = new System.Drawing.Point(332, 129);
            this.playerPoints.Name = "playerPoints";
            this.playerPoints.Size = new System.Drawing.Size(109, 13);
            this.playerPoints.TabIndex = 9;
            this.playerPoints.Text = "                                  ";
            this.playerPoints.Click += new System.EventHandler(this.label5_Click);
            // 
            // rollDice
            // 
            this.rollDice.BackColor = System.Drawing.Color.Aqua;
            this.rollDice.Location = new System.Drawing.Point(11, 9);
            this.rollDice.Name = "rollDice";
            this.rollDice.Size = new System.Drawing.Size(104, 44);
            this.rollDice.TabIndex = 10;
            this.rollDice.Text = "Roll Dice";
            this.rollDice.UseVisualStyleBackColor = false;
            this.rollDice.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // dice2
            // 
            this.dice2.AutoSize = true;
            this.dice2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.dice2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dice2.Location = new System.Drawing.Point(68, 94);
            this.dice2.Name = "dice2";
            this.dice2.Size = new System.Drawing.Size(145, 20);
            this.dice2.TabIndex = 14;
            this.dice2.Text = "                                  ";
            this.dice2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.dice2.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "Dice 2";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // dice1
            // 
            this.dice1.AutoSize = true;
            this.dice1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.dice1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dice1.Location = new System.Drawing.Point(68, 63);
            this.dice1.Name = "dice1";
            this.dice1.Size = new System.Drawing.Size(145, 20);
            this.dice1.TabIndex = 12;
            this.dice1.Text = "                                  ";
            this.dice1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.dice1.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(8, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "Dice 1";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.BackColor = System.Drawing.SystemColors.Control;
            this.resultLabel.Font = new System.Drawing.Font("Papyrus", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.resultLabel.Location = new System.Drawing.Point(321, 331);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(139, 46);
            this.resultLabel.TabIndex = 15;
            this.resultLabel.Text = "                 ";
            this.resultLabel.Click += new System.EventHandler(this.resultLabel_Click);
            // 
            // quit
            // 
            this.quit.BackColor = System.Drawing.Color.Salmon;
            this.quit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.quit.Location = new System.Drawing.Point(168, 137);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(104, 44);
            this.quit.TabIndex = 16;
            this.quit.Text = "Quit";
            this.quit.UseVisualStyleBackColor = false;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // editPlayer
            // 
            this.editPlayer.Location = new System.Drawing.Point(286, 63);
            this.editPlayer.Name = "editPlayer";
            this.editPlayer.Size = new System.Drawing.Size(102, 44);
            this.editPlayer.TabIndex = 17;
            this.editPlayer.Text = "Edit Player";
            this.editPlayer.UseVisualStyleBackColor = true;
            this.editPlayer.Click += new System.EventHandler(this.editPlayer_Click);
            // 
            // deletePlayer
            // 
            this.deletePlayer.BackColor = System.Drawing.Color.Salmon;
            this.deletePlayer.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.deletePlayer.Location = new System.Drawing.Point(151, 164);
            this.deletePlayer.Name = "deletePlayer";
            this.deletePlayer.Size = new System.Drawing.Size(102, 44);
            this.deletePlayer.TabIndex = 18;
            this.deletePlayer.Text = "Delete Player";
            this.deletePlayer.UseVisualStyleBackColor = false;
            this.deletePlayer.Visible = false;
            this.deletePlayer.Click += new System.EventHandler(this.deletePlayer_Click);
            // 
            // clearHistory
            // 
            this.clearHistory.Location = new System.Drawing.Point(618, 63);
            this.clearHistory.Name = "clearHistory";
            this.clearHistory.Size = new System.Drawing.Size(102, 44);
            this.clearHistory.TabIndex = 19;
            this.clearHistory.Text = "Clear History";
            this.clearHistory.UseVisualStyleBackColor = true;
            this.clearHistory.Click += new System.EventHandler(this.clearHistory_Click);
            // 
            // playerName
            // 
            this.playerName.Enabled = false;
            this.playerName.Location = new System.Drawing.Point(103, 129);
            this.playerName.Name = "playerName";
            this.playerName.Size = new System.Drawing.Size(106, 20);
            this.playerName.TabIndex = 20;
            // 
            // saveUser
            // 
            this.saveUser.BackColor = System.Drawing.Color.Green;
            this.saveUser.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.saveUser.Location = new System.Drawing.Point(15, 164);
            this.saveUser.Name = "saveUser";
            this.saveUser.Size = new System.Drawing.Size(102, 44);
            this.saveUser.TabIndex = 21;
            this.saveUser.Text = "Save";
            this.saveUser.UseVisualStyleBackColor = false;
            this.saveUser.Visible = false;
            this.saveUser.Click += new System.EventHandler(this.saveUser_Click);
            // 
            // GameHistory
            // 
            this.GameHistory.AllowUserToAddRows = false;
            this.GameHistory.AllowUserToDeleteRows = false;
            this.GameHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GameHistory.Location = new System.Drawing.Point(524, 129);
            this.GameHistory.Name = "GameHistory";
            this.GameHistory.ReadOnly = true;
            this.GameHistory.Size = new System.Drawing.Size(344, 334);
            this.GameHistory.TabIndex = 22;
            // 
            // PlayerDataView
            // 
            this.PlayerDataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PlayerDataView.Location = new System.Drawing.Point(17, 237);
            this.PlayerDataView.Name = "PlayerDataView";
            this.PlayerDataView.Size = new System.Drawing.Size(241, 226);
            this.PlayerDataView.TabIndex = 23;
            this.PlayerDataView.Visible = false;
            this.PlayerDataView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PlayerDataView_CellClick);
            // 
            // PlayerDataLabel
            // 
            this.PlayerDataLabel.AutoSize = true;
            this.PlayerDataLabel.Location = new System.Drawing.Point(117, 221);
            this.PlayerDataLabel.Name = "PlayerDataLabel";
            this.PlayerDataLabel.Size = new System.Drawing.Size(41, 13);
            this.PlayerDataLabel.TabIndex = 24;
            this.PlayerDataLabel.Text = "Players";
            this.PlayerDataLabel.Visible = false;
            // 
            // GamePanel
            // 
            this.GamePanel.Controls.Add(this.Replay);
            this.GamePanel.Controls.Add(this.rollDice);
            this.GamePanel.Controls.Add(this.quit);
            this.GamePanel.Controls.Add(this.label8);
            this.GamePanel.Controls.Add(this.label6);
            this.GamePanel.Controls.Add(this.dice1);
            this.GamePanel.Controls.Add(this.dice2);
            this.GamePanel.Location = new System.Drawing.Point(27, 263);
            this.GamePanel.Name = "GamePanel";
            this.GamePanel.Size = new System.Drawing.Size(288, 231);
            this.GamePanel.TabIndex = 25;
            this.GamePanel.Visible = false;
            // 
            // Replay
            // 
            this.Replay.BackColor = System.Drawing.Color.DarkGreen;
            this.Replay.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Replay.Location = new System.Drawing.Point(13, 137);
            this.Replay.Name = "Replay";
            this.Replay.Size = new System.Drawing.Size(102, 44);
            this.Replay.TabIndex = 26;
            this.Replay.Text = "Replay";
            this.Replay.UseVisualStyleBackColor = false;
            this.Replay.Visible = false;
            this.Replay.Click += new System.EventHandler(this.Replay_Click);
            // 
            // CrapsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 526);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.GamePanel);
            this.Controls.Add(this.PlayerDataLabel);
            this.Controls.Add(this.GameHistory);
            this.Controls.Add(this.saveUser);
            this.Controls.Add(this.playerName);
            this.Controls.Add(this.clearHistory);
            this.Controls.Add(this.deletePlayer);
            this.Controls.Add(this.editPlayer);
            this.Controls.Add(this.playerPoints);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.loadPlayer);
            this.Controls.Add(this.newPlayer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PlayerDataView);
            this.Name = "CrapsForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GameHistory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerDataView)).EndInit();
            this.GamePanel.ResumeLayout(false);
            this.GamePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button newPlayer;
        private System.Windows.Forms.Button loadPlayer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label playerPoints;
        private System.Windows.Forms.Button rollDice;
        private System.Windows.Forms.Label dice2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label dice1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.Button editPlayer;
        private System.Windows.Forms.Button deletePlayer;
        private System.Windows.Forms.Button clearHistory;
        private System.Windows.Forms.TextBox playerName;
        private System.Windows.Forms.Button saveUser;
        private System.Windows.Forms.DataGridView GameHistory;
        private System.Windows.Forms.DataGridView PlayerDataView;
        private System.Windows.Forms.Label PlayerDataLabel;
        private System.Windows.Forms.Panel GamePanel;
        private System.Windows.Forms.Button Replay;
    }
}

