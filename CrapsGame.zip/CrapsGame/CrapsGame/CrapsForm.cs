﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static DataLibrary.GameLogic.GameProcessor;

namespace CrapsGame
{
    public partial class CrapsForm : Form
    {
        private string currentPlayerName;
        private int currentPlayerId;
        private bool isplayerInit;
        private bool isAdd;
        private int point = 0;
        public CrapsForm()
        {
            InitializeComponent();
            ApiHelper.InitializeClient();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            deletePlayer.IsAccessible = false;
            isplayerInit = false;
            isAdd = false;
            clearHistory.Enabled = false;
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            isAdd = true;
            saveUser.Visible = true;
            saveUser.Enabled = true;
            playerName.Enabled = true;
            GamePanel.Visible = false;
            GameHistory.ClearSelection();
            clearHistory.Enabled = false;
            PlayerDataView.Visible = false;
            PlayerDataLabel.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var data = LoadPlayers();
            PlayerDataView.DataSource = data;
            PlayerDataView.Visible = true;
            PlayerDataLabel.Visible = true;
            GamePanel.Visible = false;
            GameHistory.ClearSelection();
            clearHistory.Enabled = false;
            saveUser.Visible = false;
            playerName.Enabled = false;
        }

        private void editPlayer_Click(object sender, EventArgs e)
        {
            isAdd = false;
            saveUser.Visible = true;
            saveUser.Enabled = true;
            playerName.Enabled = true;
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private  void resetGame()
        {
            point = 0;
            dice1.Text = "";
            dice2.Text = "";
            rollDice.Enabled = true;
            resultLabel.Text = "";
            Replay.Visible = false;

        }
        private async Task RollDice()
        {
            var dice = await DiceProcessor.RollDice();
            dice1.Text = dice.Result.ToString();
            dice = await DiceProcessor.RollDice();
            dice2.Text = dice.Result.ToString();

            int sum = Convert.ToInt16(dice1.Text) + Convert.ToInt16(dice2.Text);

            if (point == 0)
            {
                if (sum == 7 || sum == 11)
                {
                    //player win
                    resultLabel.Text = "YOU WIN!";
                    SaveGame(currentPlayerId, "WIN", sum);
                    var data = LoadScores(currentPlayerId);
                    GameHistory.DataSource = data;
                    rollDice.Enabled = false;
                    Replay.Visible = true;
                }

                if (sum == 2 || sum == 3 || sum == 12)
                {
                    //Player lose
                    resultLabel.Text = "YOU LOSE!";
                    SaveGame(currentPlayerId, "LOSE", sum);
                    var data = LoadScores(currentPlayerId);
                    GameHistory.DataSource = data;
                    rollDice.Enabled = false;
                    Replay.Visible = true;
                }
                else
                {
                    point = sum;
                    resultLabel.Text = "SUM: " + point.ToString();
                }
            }
            else
            {
                if (sum == 7)
                {
                    resultLabel.Text = "YOU LOSE!";
                    SaveGame(currentPlayerId, "LOSE", sum);
                    var data = LoadScores(currentPlayerId);
                    GameHistory.DataSource = data;
                    rollDice.Enabled = false;
                    Replay.Visible = true;
                }
                else if (sum == point)
                {
                    resultLabel.Text = "YOU WIN!";
                    SaveGame(currentPlayerId, "WIN", sum);
                    var data = LoadScores(currentPlayerId);
                    GameHistory.DataSource = data;
                    rollDice.Enabled = false;
                    Replay.Visible = true;
                }
                else
                {
                    point = sum;
                    resultLabel.Text = "SUM: " + point.ToString();
                   
                }
            }
        }
        //Roll Dice
        private async void button3_Click_1(object sender, EventArgs e)
        {
            await RollDice();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void resultLabel_Click(object sender, EventArgs e)
        {

        }

        private void saveUser_Click(object sender, EventArgs e)
        {
            string playerNameString = playerName.Text;
            if (string.IsNullOrEmpty(playerNameString))
            {
                string message = "Please enter Player's Name";
                string caption = "Error Detected in Input";
                MessageBox.Show(message, caption);
            }
            else if (isAdd)
            {

                int recordId = CreatePlayer(playerName.Text);

                currentPlayerName = playerName.Text;
                currentPlayerId = recordId;
                saveUser.Visible = false;
                saveUser.Enabled = false;
                playerName.Enabled = false;
                GamePanel.Visible = true;

                clearHistory.Enabled = true;
            }
            else
            {
                int record = EditPlayer(currentPlayerId,playerName.Text);
                if (record == 1)
                {
                    currentPlayerName = playerName.Text;

                }
                saveUser.Visible = false;
                saveUser.Enabled = false;
                playerName.Enabled = false;
                GamePanel.Visible = true;
                clearHistory.Enabled = true;
            }
        }

           
        

        private void PlayerDataView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            currentPlayerId = Convert.ToInt16(PlayerDataView.CurrentRow.Cells[1].Value.ToString());
            currentPlayerName = PlayerDataView.CurrentRow.Cells[0].Value.ToString();
            PlayerDataLabel.Visible = false;
            PlayerDataView.Visible = false;
            GamePanel.Visible = true;
            var data = LoadScores(currentPlayerId);
            GameHistory.DataSource = data;
            clearHistory.Enabled = true;
            deletePlayer.Visible = true;
            playerName.Text = currentPlayerName;
            resetGame();

        }

        private void deletePlayer_Click(object sender, EventArgs e)
        {
            int record = DeletePlayer(currentPlayerId);
            GamePanel.Visible = false;
            clearHistory.Enabled = false;
            PlayerDataLabel.Visible = false;
            PlayerDataView.Visible = false;
            deletePlayer.Visible = false;
            playerName.Text = "";
        }

        private void quit_Click(object sender, EventArgs e)
        {
            resetGame();
        }

        private void Replay_Click(object sender, EventArgs e)
        {
            Replay.Visible = false;
            resetGame();
        }

        private void clearHistory_Click(object sender, EventArgs e)
        {
            ClearGame(currentPlayerId);
            var data = LoadScores(currentPlayerId);
            GameHistory.DataSource = data;
        }
    }
}
