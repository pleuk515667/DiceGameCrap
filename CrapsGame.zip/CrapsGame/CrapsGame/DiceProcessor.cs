﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;

namespace CrapsGame
{
    public class DiceProcessor
    {
        public static async Task<DiceModel> RollDice()
        {
            string url = "https://rolz.org/api/?1d6.json";

            using (HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync(url))
            {
                if (response.IsSuccessStatusCode)
                {
                    DiceModel dice = await response.Content.ReadAsAsync<DiceModel>();
                    return dice;
                }
                else
                {
                    throw new Exception(response.ReasonPhrase);
                }
            }

        }

    }
}
