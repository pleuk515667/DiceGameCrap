﻿CREATE TABLE [dbo].[Score]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Score] INT NOT NULL, 
    [Result] NVARCHAR(50) NOT NULL, 
    [PlayerId] INT NOT NULL
)
